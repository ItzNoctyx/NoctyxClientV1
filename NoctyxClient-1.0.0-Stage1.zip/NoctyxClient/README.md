# Noctyx Client — Stage 1

A client-side Fabric mod starter for Minecraft 1.21.11.

## Included in this stage
- Right Shift keybind opens/closes the Noctyx Click GUI.
- Glass-inspired dark GUI with category sidebar.
- Module registry and clickable ON/OFF toggles.
- All 14 requested feature names registered in categories.

**Important:** The feature entries are currently GUI/module placeholders. They do not yet implement FPS/CPS rendering, keystrokes, sprint behavior, zoom, HUD positioning, world visual changes, mod search, or cosmetics. Those need their own implementation stages.

## Requirements
- JDK 21
- IntelliJ IDEA Community (recommended)
- Fabric Loader for Minecraft 1.21.11
- Fabric API for Minecraft 1.21.11

## Open and build
1. Extract this folder.
2. Open the `NoctyxClient` folder in IntelliJ IDEA as a Gradle project.
3. Make sure Gradle uses JDK 21: Settings → Build Tools → Gradle → Gradle JVM.
4. Check `gradle.properties`. If a listed Fabric version is no longer available, replace it with the recommended matching version from https://fabricmc.net/develop/ for Minecraft 1.21.11.
5. Reload Gradle.
6. Run the `runClient` Gradle task.
7. In Minecraft, press Right Shift to open the GUI.
8. Build the mod with the Gradle `build` task. The output JAR is in `build/libs/`.

## Install
Copy the remapped mod JAR from `build/libs/` into the `mods` folder of a Fabric 1.21.11 instance. Install Fabric API in that instance too.

## Package layout
- `NoctyxClient.java`: client entrypoint and Right Shift binding.
- `gui/ClickGuiScreen.java`: first version of the glass-style GUI.
- `module/ClientModule.java`: base module state.
- `module/ModuleManager.java`: feature registry.
- `module/ModuleCategory.java`: sidebar categories.

## Next development stages
1. Implement live HUD rendering and HUD editor.
2. Implement CPS and keystrokes input tracking.
3. Implement zoom and toggle sprint.
4. Implement armor and potion HUD.
5. Implement crosshair settings.
6. Add local time/weather visual overrides.
7. Add installed-mod search and cosmetic preview support.
8. Add persistent JSON configuration and polished textures/animations.
