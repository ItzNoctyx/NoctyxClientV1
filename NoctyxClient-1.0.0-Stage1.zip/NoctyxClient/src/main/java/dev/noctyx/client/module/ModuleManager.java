package dev.noctyx.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<ClientModule> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        if (!MODULES.isEmpty()) return;

        // HUD modules
        register("FPS Counter", "Displays the current frames per second.", ModuleCategory.HUD);
        register("CPS Counter", "Counts left and right mouse clicks.", ModuleCategory.HUD);
        register("Keystrokes", "Displays movement keys and mouse buttons.", ModuleCategory.HUD);
        register("Armor HUD", "Displays equipped armor.", ModuleCategory.HUD);
        register("Coordinates", "Displays your current XYZ coordinates.", ModuleCategory.HUD);
        register("Potion HUD", "Displays active status effects.", ModuleCategory.HUD);
        register("HUD Editor", "Customize HUD element positions and scale.", ModuleCategory.HUD);

        // Player modules
        register("Toggle Sprint", "Keeps sprint enabled while movement allows it.", ModuleCategory.PLAYER);
        register("Zoom", "Provides a configurable client-side zoom.", ModuleCategory.PLAYER);

        // Visual modules
        register("Crosshair Customizer", "Customize crosshair appearance.", ModuleCategory.VISUAL);
        register("Custom Cosmetics", "Client-side cosmetic preview framework.", ModuleCategory.VISUAL);

        // World modules
        register("Time Changer", "Changes the locally displayed world time.", ModuleCategory.WORLD);
        register("Weather Changer", "Changes locally rendered weather visuals.", ModuleCategory.WORLD);

        // Utility modules
        register("Mod Search", "Search installed mods by name.", ModuleCategory.UTILITY);
    }

    private static void register(String name, String description, ModuleCategory category) {
        MODULES.add(new ClientModule(name, description, category));
    }

    public static List<ClientModule> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<ClientModule> getModules(ModuleCategory category) {
        return MODULES.stream()
                .filter(module -> module.getCategory() == category)
                .toList();
    }
}
