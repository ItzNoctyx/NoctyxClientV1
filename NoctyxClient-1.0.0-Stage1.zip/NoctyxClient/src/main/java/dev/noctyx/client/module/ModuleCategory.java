package dev.noctyx.client.module;

public enum ModuleCategory {
    HUD("HUD"),
    PLAYER("Player"),
    VISUAL("Visual"),
    WORLD("World"),
    UTILITY("Utility");

    private final String displayName;

    ModuleCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
