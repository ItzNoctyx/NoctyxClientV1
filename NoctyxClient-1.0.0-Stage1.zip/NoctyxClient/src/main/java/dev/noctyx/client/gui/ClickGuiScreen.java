package dev.noctyx.client.gui;

import dev.noctyx.client.module.ClientModule;
import dev.noctyx.client.module.ModuleCategory;
import dev.noctyx.client.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public final class ClickGuiScreen extends Screen {
    private static final int PANEL_WIDTH = 390;
    private static final int PANEL_HEIGHT = 270;
    private static final int BG = 0xD9101420;
    private static final int PANEL = 0xD91C2433;
    private static final int PANEL_LIGHT = 0xD9273448;
    private static final int ACCENT = 0xFF9B7BFF;
    private static final int TEXT = 0xFFF1F3FA;
    private static final int MUTED = 0xFF9AA7BB;
    private ModuleCategory selectedCategory = ModuleCategory.HUD;

    public ClickGuiScreen() {
        super(Text.literal("Noctyx Client"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dim overlay plus translucent panels creates a glass-inspired look.
        context.fill(0, 0, width, height, 0x88060A12);

        int left = (width - PANEL_WIDTH) / 2;
        int top = (height - PANEL_HEIGHT) / 2;
        int right = left + PANEL_WIDTH;
        int bottom = top + PANEL_HEIGHT;

        context.fill(left, top, right, bottom, BG);
        context.fill(left, top, right, top + 42, 0xE5222B3D);
        context.fill(left, top, left + 3, bottom, ACCENT);

        context.drawTextWithShadow(textRenderer, Text.literal("NOCTYX CLIENT"), left + 17, top + 12, TEXT);
        context.drawTextWithShadow(textRenderer, Text.literal("1.0.0  •  FABRIC 1.21.11"),
                right - 145, top + 14, MUTED);

        // Category sidebar
        int sideX = left + 12;
        int sideY = top + 55;
        for (ModuleCategory category : ModuleCategory.values()) {
            boolean active = category == selectedCategory;
            int y = sideY + category.ordinal() * 34;
            if (active) {
                context.fill(sideX, y - 5, sideX + 104, y + 21, 0xAA514477);
                context.fill(sideX, y - 5, sideX + 2, y + 21, ACCENT);
            }
            context.drawTextWithShadow(textRenderer, Text.literal(category.getDisplayName()),
                    sideX + 9, y + 3, active ? TEXT : MUTED);
        }

        // Module list
        int listX = left + 132;
        int listY = top + 55;
        List<ClientModule> modules = ModuleManager.getModules(selectedCategory);
        int row = 0;
        for (ClientModule module : modules) {
            int y = listY + row * 37;
            int color = module.isEnabled() ? 0xCC34304F : PANEL;
            context.fill(listX, y, right - 14, y + 29, color);
            context.drawTextWithShadow(textRenderer, Text.literal(module.getName()),
                    listX + 9, y + 5, TEXT);
            context.drawTextWithShadow(textRenderer,
                    Text.literal(module.isEnabled() ? "ON" : "OFF"),
                    right - 49, y + 5, module.isEnabled() ? 0xFF9BE7C2 : MUTED);
            context.drawTextWithShadow(textRenderer, Text.literal(module.getDescription()),
                    listX + 9, y + 17, MUTED);
            row++;
        }

        context.drawTextWithShadow(textRenderer,
                Text.literal("Right Shift: close  •  Click a module to toggle"),
                left + 14, bottom - 17, MUTED);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) return super.mouseClicked(mouseX, mouseY, button);

        int left = (width - PANEL_WIDTH) / 2;
        int top = (height - PANEL_HEIGHT) / 2;

        // Category selection
        int sideX = left + 12;
        int sideY = top + 55;
        for (ModuleCategory category : ModuleCategory.values()) {
            int y = sideY + category.ordinal() * 34;
            if (inside(mouseX, mouseY, sideX, y - 5, sideX + 104, y + 21)) {
                selectedCategory = category;
                return true;
            }
        }

        // Module toggle rows
        int listX = left + 132;
        int listY = top + 55;
        List<ClientModule> modules = ModuleManager.getModules(selectedCategory);
        for (int i = 0; i < modules.size(); i++) {
            int y = listY + i * 37;
            if (inside(mouseX, mouseY, listX, y, left + PANEL_WIDTH - 14, y + 29)) {
                modules.get(i).toggle();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private boolean inside(double x, double y, int x1, int y1, int x2, int y2) {
        return x >= x1 && x <= x2 && y >= y1 && y <= y2;
    }
}
